# Attribution and limits

Bunting, Pete; Rosenqvist, Ake; Hilarides, Lammert; Lucas, Richard; Thomas, Nathan; Tadono, Takeo; Worthington, Thomas; Spalding, Mark; Murray, Nicholas; Rebelo, Lisa-Maria. (2022). Global Mangrove Watch (1996 - 2020) Version 3.0 Dataset. https://doi.org/10.5281/zenodo.6894273

CC BY 4.0: https://creativecommons.org/licenses/by/4.0/
Modifications: two native tiles cropped; values sampled onto the SCL grid; imagery contrast stretched. No endorsement implied.
Contains modified Copernicus Sentinel data (2018), accessed previously through Microsoft Planetary Computer.
GMW is a separate extent reference, not field truth or a health label. The 2018 epoch is not the exact Sentinel acquisition date.
We deliberately retain v3 for the specified historical experiment; this does not claim it is the latest or best available release.

Additional modifications: November 30 Sentinel-2 crop, common-grid SCL comparison and shared-stretch displays. Contains modified Copernicus Sentinel data (2018).

Additional modifications: 2x2 mean red/NIR contrast, fixed geographic split, threshold predictions and GMW agreement statistics.

Additional modifications: frozen-prediction audit, connected components, cell/cluster tables and NIR inspection panels.
