# Historical Khor Kalba observation requests

85 original cell centres; NOT flight waypoints, sampling locations or landing sites.
No field observations, operational access or planting recommendation established.
Current observations cannot directly validate November 2018 cover.
