Planet Tanager scene 20250511_074311_00_4001 (11 May 2025), CC BY 4.0. Source: https://www.planet.com/data/stac/catalog.json
Modifications: native-grid visual/mask display and fixed-window channel sampling. No endorsement. Masks are beta quality context, not truth. Team analysis does not validate mangrove identity, health or drone/ecological benefit.
