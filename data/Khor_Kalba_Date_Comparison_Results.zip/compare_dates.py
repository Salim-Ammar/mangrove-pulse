"""Fixed-AOI SCL quality comparison; run only in the user's Colab runtime."""
from pathlib import Path
import sys,json,zipfile,hashlib,shutil,csv,re,time,traceback,importlib.metadata
from datetime import datetime,timezone
from urllib.parse import urlsplit

OLD_ID='S2B_MSIL2A_20181120T065159_R020_T40RDN_20201008T201621'
NEW_ID='S2B_MSIL2A_20181130T065229_R020_T40RDN_20201008T230116'
ITEM_URL='https://planetarycomputer.microsoft.com/api/stac/v1/collections/sentinel-2-l2a/items/'+NEW_ID
BBOX=[56.35,24.986,56.374,25.006]
KEYS=['SCL','B02','B03','B04','B08']
LABELS=['No data','Defective','Dark area','Cloud shadow','Vegetation','Nonvegetated','Water','Unclassified','Cloud medium','Cloud high','Cirrus','Snow/ice']
GROUPS={'cloud_cirrus_shadow':[3,8,9,10],'nodata_defective':[0,1],'dark_unclassified':[2,7],'snow_ice':[11],'water':[6],'vegetation':[4],'nonvegetated':[5]}
STAGE='start'
def stage(s):
 global STAGE
 STAGE=s;print('\n'+s,flush=True)
def dump(p,o):p.write_text(json.dumps(o,indent=2,ensure_ascii=False))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def safe(s):return re.sub(r'https?://[^\s<>\"\']+','[URL redacted]',str(s))
def run(input_zip,out):
 import numpy as np
 import requests,planetary_computer as pc,rasterio
 from rasterio.windows import Window,from_bounds
 from rasterio.transform import array_bounds
 from rasterio.features import geometry_mask
 from rasterio.warp import transform_geom
 from rasterio.plot import plotting_extent
 import matplotlib
 matplotlib.use('Agg')
 import matplotlib.pyplot as plt
 from matplotlib.colors import ListedColormap,BoundaryNorm
 stage('1/4 Check the successful GMW-results package')
 prior=out/'previous';prior.mkdir()
 required=['run_status.json','overlay_summary.json','input_manifest.json','reference_manifest.json','ATTRIBUTION.md','gmw2018_on_scl_grid.tif','input_crops/item_unsigned.json']+['input_crops/'+k+'_crop.tif' for k in KEYS]
 with zipfile.ZipFile(input_zip) as z:
  for name in required:
   members=[i for i in z.infolist() if i.filename==name]
   if len(members)!=1 or members[0].file_size>50_000_000:raise ValueError('Missing/duplicate/oversized member: '+name+'. Upload the GMW-results ZIP, not the pixel-results ZIP.')
   dest=prior/name;dest.parent.mkdir(parents=True,exist_ok=True)
   with z.open(members[0]) as src,dest.open('wb') as dst:shutil.copyfileobj(src,dst)
 status=json.loads((prior/'run_status.json').read_text());old_report=json.loads((prior/'overlay_summary.json').read_text())
 if status.get('status')!='succeeded':raise ValueError('Previous GMW run was not successful.')
 if old_report['item_id']!=OLD_ID or not np.allclose(old_report['bbox_lonlat'],BBOX,atol=1e-10,rtol=0):raise ValueError('Wrong previous item or AOI.')
 manifest=json.loads((prior/'input_manifest.json').read_text())
 for name,h in manifest['crop_sha256'].items():
  if Path(name).name!=name or sha(prior/'input_crops'/name)!=h:raise ValueError('Previous crop checksum mismatch.')
 ref=json.loads((prior/'reference_manifest.json').read_text())
 if ref.get('version')!='3.0' or ref.get('md5')!='6bda7daf2b7a3f31451c2d2713d3318b':raise ValueError('Unexpected GMW reference version/checksum.')
 old_item=json.loads((prior/'input_crops/item_unsigned.json').read_text())
 if old_item.get('id')!=OLD_ID:raise ValueError('Old STAC metadata mismatch.')
 dump(out/'input_manifest.json',{'zip_name':input_zip.name,'sha256':sha(input_zip),'reference_mask_sha256':sha(prior/'gmw2018_on_scl_grid.tif'),'bbox_lonlat':BBOX,'old_item':OLD_ID,'new_item':NEW_ID})
 old={};profiles={};extents={}
 for key in KEYS:
  with rasterio.open(prior/'input_crops'/(key+'_crop.tif')) as ds:
   if ds.count!=1 or ds.crs.to_epsg()!=32640 or ds.width*ds.height>2_000_000:raise ValueError('Unexpected old crop geometry.')
   expected=20 if key=='SCL' else 10
   if not np.allclose(ds.res,[expected,expected],atol=1e-9,rtol=0):raise ValueError('Unexpected old resolution.')
   old[key]=ds.read(1);profiles[key]=ds.profile.copy();extents[key]=plotting_extent(ds)
 with rasterio.open(prior/'gmw2018_on_scl_grid.tif') as ds:
  if ds.crs!=profiles['SCL']['crs'] or ds.transform!=profiles['SCL']['transform'] or ds.shape!=old['SCL'].shape:raise ValueError('Reference/SCL grid mismatch.')
  reference=ds.read(1)
  if not set(np.unique(reference)).issubset({0,1,255}):raise ValueError('Unexpected reference codes.')
 inside=reference!=255;foot=(reference==1);shape=reference.shape;tx=profiles['SCL']['transform']
 if int(inside.sum())!=old_report['aoi_centres'] or int(foot.sum())!=old_report['gmw_positive_centres']:raise ValueError('Reference counts disagree with old report.')
 if any(int(((old['SCL']==row['class'])&foot).sum())!=row['pixels'] for row in old_report['scl_within_gmw']):raise ValueError('Old SCL counts no longer match.')
 padded=np.pad(foot,1);interior=np.logical_and.reduce([padded[i:i+shape[0],j:j+shape[1]] for i in range(3) for j in range(3)])
 if int(interior.sum())!=old_report['interior_20m_erosion']['centres']:raise ValueError('Interior footprint differs from the previous run.')
 stage('2/4 Fetch the fixed November 30 item and read five small native-grid windows')
 item=None
 for attempt in range(3):
  try:
   response=requests.get(ITEM_URL,timeout=(20,60));response.raise_for_status();item=response.json();break
  except Exception as exc:
   print('Metadata attempt',attempt+1,'failed:',type(exc).__name__,flush=True)
   if attempt==2:raise RuntimeError('Could not retrieve November 30 metadata: '+safe(exc)) from None
   time.sleep(3*(attempt+1))
 prop=item['properties']
 if item.get('id')!=NEW_ID or not prop['datetime'].startswith('2018-11-30') or prop.get('s2:mgrs_tile')!='40RDN':raise ValueError('Provider returned the wrong item/date/tile.')
 # Require comparable processing metadata for the qualitative shared-DN displays.
 checks=['platform','sat:relative_orbit','s2:processing_baseline','s2:product_type']
 for k in checks:
  if prop.get(k) is None or prop[k]!=old_item['properties'].get(k):raise ValueError('Acquisition/processing metadata differs: '+k+'. Review required; do not auto-adjust.')
 for key in KEYS:
  href=item['assets'][key]['href'];u=urlsplit(href)
  if u.scheme!='https' or not u.hostname.endswith('.blob.core.windows.net') or u.query:raise ValueError('Unexpected or already signed asset location.')
 dump(out/'nov30_item_unsigned.json',item)
 newdir=out/'nov30_crops';newdir.mkdir();new={};asset_report={}
 for key in KEYS:
  print('  Reading',key,flush=True)
  p=profiles[key];h,w=old[key].shape
  bounds=array_bounds(h,w,p['transform'])
  # Sign in memory only. Neither signed URLs nor raw provider errors are saved.
  try:
   signed=pc.sign(item['assets'][key]['href'])
   with rasterio.Env(GDAL_DISABLE_READDIR_ON_OPEN='EMPTY_DIR',GDAL_HTTP_TIMEOUT='60',GDAL_HTTP_MAX_RETRY='2',GDAL_HTTP_RETRY_DELAY='2',CPL_CURL_VERBOSE=False):
    with rasterio.open(signed) as ds:
     if ds.crs!=p['crs'] or ds.count!=1:raise ValueError('New source CRS/bands mismatch.')
     win=from_bounds(*bounds,transform=ds.transform)
     coords=[win.col_off,win.row_off,win.width,win.height]
     if not np.allclose(coords,np.round(coords),atol=1e-6,rtol=0):raise ValueError('Dates are not on the same native grid. No automatic resampling.')
     c,r,ww,hh=map(int,np.round(coords));win=Window(c,r,ww,hh)
     if ww!=w or hh!=h or min(c,r)<0 or c+ww>ds.width or r+hh>ds.height:raise ValueError('New asset does not cover the exact old crop.')
     if not np.allclose(list(ds.window_transform(win)),list(p['transform']),atol=1e-6,rtol=0):raise ValueError('New window transform differs.')
     arr=ds.read(1,window=win,masked=True)
     # Sentinel no-data zero is retained; quality flags remain explicit.
     data=np.asarray(arr.filled(0));missing=np.ma.getmaskarray(arr)|(data==0)
     new[key]=data
     prof=ds.profile.copy();prof.update(driver='GTiff',count=1,height=h,width=w,transform=p['transform'],compress='deflate')
     dest=newdir/(key+'_crop.tif')
     with rasterio.open(dest,'w',**prof) as d:d.write(data,1)
     asset_report[key]={'shape':[h,w],'transform':list(p['transform']),'crs':str(p['crs']),'resolution':list(ds.res),'sha256':sha(dest),'nodata_metadata':ds.nodata,'crop_rectangle_missing_percent':float(missing.mean()*100)}
  except Exception as exc:raise RuntimeError('Remote crop '+key+' failed: '+safe(exc)) from None
 for key in ['B02','B03','B08']:
  if old[key].shape!=old['B04'].shape or profiles[key]['transform']!=profiles['B04']['transform']:raise ValueError('RGB/NIR grid mismatch.')
 if not set(np.unique(new['SCL'][inside])).issubset(set(range(12))):raise ValueError('Unexpected new SCL class.')
 stage('3/4 Compare flags on the unchanged reference footprint')
 regions={'aoi':inside,'gmw_full':foot,'gmw_interior':interior};rows=[];summaries={};transitions={}
 for region,m in regions.items():
  n=int(m.sum());summaries[region]={'denominator_centres':n,'dates':{}}
  for date,a in [('2018-11-20',old['SCL']),('2018-11-30',new['SCL'])]:
   groups={name:{'centres':int(np.isin(a,codes)[m].sum()),'percent':float(np.isin(a,codes)[m].mean()*100) if n else None} for name,codes in GROUPS.items()}
   summaries[region]['dates'][date]=groups
   for name,v in groups.items():rows.append({'region':region,'date':date,'group':name,'centres':v['centres'],'denominator':n,'percent':v['percent']})
  before=summaries[region]['dates']['2018-11-20'];after=summaries[region]['dates']['2018-11-30']
  summaries[region]['percentage_point_difference_nov30_minus_nov20']={k:after[k]['percent']-before[k]['percent'] if n else None for k in GROUPS}
  matrix=np.bincount(old['SCL'][m].astype(int)*12+new['SCL'][m].astype(int),minlength=144).reshape(12,12)
  if int(matrix.sum())!=n:raise ValueError('Transition totals do not match footprint.')
  if region!='aoi':
   transitions[region]={'rows':'November 20 SCL codes 0–11','columns':'November 30 SCL codes 0–11','counts':matrix.tolist(),
    'water_both_dates':int(matrix[6,6]),'water20_vegetation30':int(matrix[6,4]),'vegetation20_water30':int(matrix[4,6]),
    'nov20_water_total':int(matrix[6,:].sum()),'nov30_water_total':int(matrix[:,6].sum())}
   with (out/(region+'_scl_transitions.csv')).open('w',newline='') as f:
    writer=csv.writer(f);writer.writerow(['Nov20_code_label / Nov30_code']+list(range(12)))
    for i,row in enumerate(matrix):writer.writerow([str(i)+' '+LABELS[i]]+row.tolist())
 with (out/'quality_comparison.csv').open('w',newline='') as f:
  writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
 fields=['datetime','platform','sat:relative_orbit','s2:mgrs_tile','s2:processing_baseline','s2:mean_solar_zenith','s2:mean_solar_azimuth','eo:cloud_cover','s2:reflectance_conversion_factor']
 report={'bbox_lonlat':BBOX,'old_item':OLD_ID,'new_item':NEW_ID,'fixed_gmw_mask_sha256':sha(prior/'gmw2018_on_scl_grid.tif'),
  'metadata_comparison':{date:{k:it['properties'].get(k) for k in fields} for date,it in [('2018-11-20',old_item),('2018-11-30',item)]},
  'grids_identical_no_resampling':True,'new_assets':asset_report,'quality_by_region':summaries,'scl_transitions':transitions,
  'limitations':['SCL label transitions are not ecological change or a validation confusion matrix.',
   'Identical raster grids do not prove subpixel image co-registration accuracy.',
   'Tide, atmospheric comparability and local reference accuracy remain unverified.',
   'No water masking or date selection based on classifier scores.',
   'Shared DN stretches are display only; no reflectance difference or vegetation index computed.',
   'The same GMW 2018 reference footprint is used for both acquisitions.']}
 dump(out/'comparison_summary.json',report)
 stage('4/4 Draw two-date inspection panels and the SCL transition heatmap')
 cuts={}
 for key in ['B02','B03','B04','B08']:
  values=np.concatenate([a[key][a[key]>0].ravel() for a in [old,new]])
  if not values.size:raise ValueError('No valid display values.')
  lo,hi=np.percentile(values,[2,98]);cuts[key]=[float(lo),float(hi)]
 def rgb(a,keys):
  cube=np.stack([np.clip((a[k].astype(float)-cuts[k][0])/max(cuts[k][1]-cuts[k][0],1),0,1) for k in keys],-1)
  cube[np.logical_or.reduce([a[k]==0 for k in keys])]=0
  return cube
 xs=tx.c+(np.arange(shape[1])+.5)*tx.a;ys=tx.f+(np.arange(shape[0])+.5)*tx.e
 fig,axes=plt.subplots(2,3,figsize=(15,12),layout='constrained')
 cm=ListedColormap(['#509653','#368ed0','#e8a32d','#ba2872','#222222']);cm.set_bad('#eeeeee')
 for row,(date,a) in enumerate([('20 Nov 2018',old),('30 Nov 2018',new)]):
  for col,(keys,title) in enumerate([(['B04','B03','B02'],'True colour'),(['B08','B04','B03'],'False colour')]):
   ax=axes[row,col];ax.imshow(rgb(a,keys),extent=extents['B04'],interpolation='nearest');ax.contour(xs,ys,foot.astype(int),levels=[.5],colors=['#ffeb00'],linewidths=.7);ax.set_title(date+' | '+title,fontsize=10)
  q=np.full(shape,np.nan);q[foot]=1;q[foot&(a['SCL']==6)]=2;q[foot&np.isin(a['SCL'],[2,7])]=3;q[foot&np.isin(a['SCL'],[3,8,9,10])]=4;q[foot&np.isin(a['SCL'],[0,1,11])]=5
  im=axes[row,2].imshow(q,extent=extents['SCL'],cmap=cm,norm=BoundaryNorm(np.arange(.5,6),5),interpolation='nearest');axes[row,2].set_title(date+' | SCL in fixed GMW footprint',fontsize=10)
 for ax in axes.flat:
  ax.set_xlim(extents['SCL'][:2]);ax.set_ylim(extents['SCL'][2:]);ax.set_aspect('equal');ax.tick_params(labelsize=7);ax.set_xlabel('UTM 40N easting (m)')
 for ax in axes[:,0]:ax.set_ylabel('Northing (m)')
 cb=fig.colorbar(im,ax=axes[:,2],location='bottom',ticks=range(1,6),fraction=.04,pad=.03);cb.ax.set_xticklabels(['Other','Water','Dark/uncertain','Cloud/shadow','No data/snow'],rotation=20,ha='right',fontsize=8)
 fig.suptitle('Khor Kalba | same GMW v3 2018 footprint on two dates\nShared display stretch; SCL label differences are not ecological change',fontsize=13)
 fig.savefig(out/'two_date_inspection.png',dpi=160,bbox_inches='tight');plt.close(fig)
 matrix=np.array(transitions['gmw_full']['counts'])
 fig,ax=plt.subplots(figsize=(9,8),layout='constrained');im=ax.imshow(matrix,cmap='Blues')
 for i in range(12):
  for j in range(12):
   if matrix[i,j]:ax.text(j,i,str(matrix[i,j]),ha='center',va='center',fontsize=8,color='white' if matrix[i,j]>matrix.max()/2 else 'black')
 ax.set_xticks(range(12),LABELS,rotation=70,ha='right');ax.set_yticks(range(12),LABELS);ax.set_xlabel('30 November SCL');ax.set_ylabel('20 November SCL');ax.set_title('SCL label transitions within fixed GMW footprint\nCounts; not a validation confusion matrix');fig.colorbar(im,ax=ax,shrink=.7)
 fig.savefig(out/'scl_transitions.png',dpi=160,bbox_inches='tight');plt.close(fig)
 dump(out/'display_stretch.json',{'method':'pooled 2–98 percentile per band, raw DN, display only','limits':cuts})
 (out/'ATTRIBUTION.md').write_text((prior/'ATTRIBUTION.md').read_text()+'\nAdditional modifications: November 30 Sentinel-2 crop, common-grid SCL comparison and shared-stretch displays. Contains modified Copernicus Sentinel data (2018).\n')
 (out/'READ_RESULTS.md').write_text('# Two-date quality comparison\n\nRead comparison_summary.json, quality_comparison.csv and both PNGs. All full-footprint percentages use the same reference cells. Interior results are sensitivity checks. Do not label SCL transitions as mangrove loss/gain or stress. Return the ZIP for review before selecting a date, changing masks or training a classifier.\n')
 print('COMPARISON READY. No automatic date approval or ecological interpretation.',flush=True)

if __name__=='__main__':
 input_zip,out=map(Path,sys.argv[1:3]);out.mkdir(parents=True,exist_ok=True)
 status={'status':'running','started_utc':datetime.now(timezone.utc).isoformat(),'execution_environment':'user Google Colab'}
 dump(out/'run_status.json',status)
 try:
  dump(out/'environment.json',{'python':sys.version,'packages':{k:importlib.metadata.version(k) for k in ['numpy','rasterio','matplotlib','requests','planetary-computer']}})
  run(input_zip,out);status.update(status='succeeded',last_stage=STAGE)
 except Exception as exc:
  status.update(status='failed',last_stage=STAGE,error_type=type(exc).__name__,error=safe(exc))
  (out/'failure.txt').write_text(safe(traceback.format_exc()));print('FAILED:',STAGE,safe(exc),flush=True)
 finally:
  status['finished_utc']=datetime.now(timezone.utc).isoformat();dump(out/'run_status.json',status)
 sys.exit(0 if status['status']=='succeeded' else 1)
