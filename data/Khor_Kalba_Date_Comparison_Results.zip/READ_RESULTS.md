# Two-date quality comparison

Read comparison_summary.json, quality_comparison.csv and both PNGs. All full-footprint percentages use the same reference cells. Interior results are sensitivity checks. Do not label SCL transitions as mangrove loss/gain or stress. Return the ZIP for review before selecting a date, changing masks or training a classifier.
