Mangrove Pulse: conditional symbolic resource audit.
PASS means algebra matched under documented assumptions, NOT hardware or ecological proof.
Seven zero-residual identities and two rational identities; no new datasets.
Preserve this JSON together with the executed notebook.
