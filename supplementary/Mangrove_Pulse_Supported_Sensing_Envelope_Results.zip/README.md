# Conditional analytical companion

Read status.json before using any output. A succeeded status means synthetic software/equation checks and export completed, not aircraft, cover or ecological validation. All empirical claims remain unproven; all actual observation counts are zero. Unknown inputs stay unknown. Synthetic examples are not team designs or missions. No flight, water contact, planting, publication or submission is authorized.
