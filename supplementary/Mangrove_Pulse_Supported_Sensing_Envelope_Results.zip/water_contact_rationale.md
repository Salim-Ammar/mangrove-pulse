# A locally grounded EO-to-contact-sensing question

7 October 2026 | Evidence-backed research rationale | No water observations or aircraft tests collected

## The concrete connection

**Question:** how do water-column conductivity and temperature vary between authorized open-channel and accessible interior-water locations, with depth and tidal context recorded?

This is a proposed, separately dated task. [Khor Kalba's official Ramsar record](https://rsis.ramsar.org/RISapp/files/RISrep/AE2125RIS.pdf), completed 1 September 2012, page 5, reports historical salinity differences between beach water (34-38 ppt) and the mangrove interior (38-44 ppt), with temperature variation. The section gives no measurement dates or sample count. It motivates investigation, not a current harm diagnosis or a salinity threshold for planting.

| Link | What it supplies | What it does not supply |
|---|---|---|
| Frozen 2018 EO/reference review | Demonstrated evidence/date/quality handling and traceable unresolved cover questions | Current cover, current water properties or independent historical truth |
| Separate dated EO context | Proposed visible water/vegetation context and explicit optical ambiguity | Water-column conductivity, sensor depth, navigable water or landing permission |
| Contact observation | Proposed calibrated conductivity/temperature, position, time, depth and tide/water-level records | Root-zone porewater, stress cause, carbon or planting suitability |
| Platform comparison | Proposed quality-matched whole-mission energy/time/cost and recovery comparison | A predetermined amphibious winner |
| Qualified evidence review | A future interpretation of accepted measurements against a defined question | Automatic intervention or established ecological benefit |

The local motivation applies to the site, not automatically to C027's historical excluded centres. Those 42 centres are not present sampling stations. C001/C017 photographic questions still have photographic comparators; contact sensing answers a different observable. No contemporary station or route is specified.

## Which data and tools earn a place?

- **Use:** the already demonstrated Sentinel-2/GMW baseline and saved WorldCover context, preserving dates and shared-reference limitations.
- **Next EO input:** Planetary Computer returns a covering candidate Sentinel-2C item `S2C_MSIL2A_20260924T064621_R020_T40RDN_20260924T114716` (24 September 2026; PB 05.13). No new pixels have been processed. Per-band encoding must be checked before computing calibrated indices; scene cloud percentage is not local quality.
- **Hyperspectral candidate:** DLR's [EnMAP catalogue](https://geoservice.dlr.de/eoc/ogc/stac/) returns item `ENMAP01-____L2A-DT0000152124_20250911T072327Z_006_V010502_20250914T181224Z`, acquired 11 September 2025: 224 advertised bands, 30 m grid, scene cloud 19%. This establishes a catalogue intersection, not valid local pixels or a useful hyperspectral result. Data-asset requests returned login HTML, not the image/product XML. Authenticate lawfully and check correction/QA/rights before an experiment. The [public ARD default](https://www.enmap.org/data_access/) is land-mode correction, not an automatically valid aquatic product.
- **Do not substitute unrelated training data:** none of the 43 individual bboxes in the checked [Planet coastal-water collection](https://www.planet.com/data/stac/tanager-core-imagery/coastal-water-bodies/collection.json) intersects this AOI. Its union bbox and the starter notebook's UAE wording do not establish Kalba coverage. Other Planet collections were not ruled out.
- **Keep optional:** Landsat for a defined longer-term contextual question; GBIF for appropriate biodiversity context, not absence/species/health truth at these cells; geojson.io for geometry inspection, not navigation validation. Add them only where they change the evidence or decision. No 813 covering scene/date was provided by the inspected Cockpit card.

Any new raster acquisition/processing belongs in a separate Colab experiment. Preserve the original threshold, split and results. Do not mix the 2025 hyperspectral scene, recent EO and 2018 cover into a single accuracy or change claim. Redistribution of EnMAP source pixels requires a check of the [applicable licence](https://geoservice.dlr.de/resources/licenses/enmap/EnMAP-Data_License_v1_1.pdf); they are not bundled here.

**Anonymous-access check, 8 October:** a bounded image-URL request returned HTTP 200 with `text/html;charset=UTF-8` and an HTML prefix, not raster bytes. The official [no-registration examples](https://www.enmap.org/data_tools/exampledata/) cover Tyrol, Groningen and Nevada, not this site. The [EnMAP-Box access documentation](https://enmap-box.readthedocs.io/en/latest/general/data_access.html) describes a registration exemption request through `enmap_registration@dlr.de` for people without institutional email. No request has been sent, exemption approved or account created. Public metadata and unrelated samples cannot substitute for local spectral observations.

## Why amphibious support is a testable improvement, not a decorative feature

The candidate mechanism is water-supported dwell: transport a suitable contact probe by air, obtain stationary accepted observations while supported, then recover it. This might reduce airborne dwell, but support mass, drift, transitions, sensing bias and failed recovery can offset the benefit. The team has not implemented this mechanism.

An [ordinary drone/boat comparison published in 2026](https://doi.org/10.1007/s10661-026-15473-0) provides an important alternative: three Irish lakes, 27 paired sonde comparisons, estimated sampling times of 28 versus 45 minutes, but higher initial drone cost and variable-specific discrepancies. It is freshwater, not an amphibious or Khor Kalba trial. Nonsignificant differences do not prove equivalence. Our comparison must include ordinary hovering probe delivery, not assume all ordinary drones only take photographs.

Choose among shore/boat probes, fixed loggers, USVs, ordinary hover delivery and supported delivery for the **same observation contract**. Prefer the least burdensome method that meets its acceptance and habitat/access constraints. No permissions, calibrated payload or safe water operation are established by this document.

## Conditional analytical claims that withstand scrutiny

With aircraft/payload mass `m0`, support mass `mf`, allowable displacement `Vallow`, water density `rho_w`, condition-specific usable thrust `Tusable`, tilt `theta`, declared lift margin `gamma >= 1`, and gravity `g`, simultaneous static buoyancy and vertical-lift constraints imply:

`mf <= min(rho_w * Vallow, Tusable * cos(theta) / (gamma * g)) - m0`.

This is a necessary design envelope, not a selected craft's performance. Inputs are unknown here, support geometry/mass are coupled, and any reserve already included in `Tusable` must not be counted twice. [Buoyancy](https://openstax.org/books/university-physics-volume-1/pages/14-4-archimedes-principle-and-buoyancy) does not establish [small-angle restoring stability](https://farside.ph.utexas.edu/teaching/336L/Fluidhtml/node29.html), wet takeoff or recovery. An empty envelope rejects that specified design; a nonempty envelope does not validate it.

For equal attempted tasks, common per-attempt acceptance rates `pH,pS > 0`, and expected whole-mission resources `EH,ES,TH,TS`, supported sensing improves both aggregate energy and time per accepted record only if:

`pS/pH > max(ES/EH, TS/TH)`.

This follows directly from comparing ratios of expectations; it is not an expected per-mission ratio. For heterogeneous tasks use the expected accepted count `sum(p_i)`. The earlier illustrative main case saves energy but takes longer at equal assumed acceptance. No measured acceptance rates, resource advantage or superiority over a UAE product are supplied.

The separate [supported-sensing envelope notebook](../supplementary/Mangrove_Pulse_Supported_Sensing_Envelope.ipynb) implements these conditional screens, strict dwell-advantage boundaries and explicit counterexamples using standard-library Python only. It embeds the empty question contract, source and 26 synthetic test definitions; it needs no additional dataset upload. It is currently an unexecuted source companion. Static source checks and a bounded read-only review are not a successful hosted run or physical validation. Its default aircraft inputs remain unknown.

## Acceptance before interpretation

The [blank water-context question contract](../examples/inspection/water_context_question.json) requires a separate date, authorized station definition, selected calibrated sensor, units/conversion, depth/time/position/tidal context, rejection rules and matched comparator. Its station list and observations are empty. No arbitrary success tolerance is populated without a sensor specification and decision requirement.

Water-column salinity is not porewater salinity. A colour/index is not chlorophyll concentration, harmful bloom toxicity or ecological damage. A measurement is useful only if it meets the contract and helps a qualified interpretation. Any planting or ecological-benefit claim still needs the [separate evidence protocol](VALIDATION_AND_BENEFIT_TESTS.md).

**Current result:** a sourced local research question, verified candidate catalogue records and conditional inequalities. **Not yet a result:** local usable hyperspectral pixels, accepted water observations, aircraft feasibility, independent 2018 accuracy or ecological improvement.
