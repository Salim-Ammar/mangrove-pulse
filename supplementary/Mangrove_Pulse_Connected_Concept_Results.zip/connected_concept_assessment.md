# Connected concept assessment: observation first, aircraft second

7 October 2026 | Proposed engineering assessment, not a prototype or deployment plan

## The complete connection

Historical satellite evidence -> unresolved question -> dated observation contract -> simplest suitable method -> physical and measurement checks -> accepted evidence -> qualified decision -> separately tested ecological outcome.

The completed PoC supplies the first two links and a traceable [observation handoff](DRONE_KHOR_KALBA_HANDOFF.md). It does not supply flight performance, independent 2018 truth or ecological outcomes. The team reconfirmed on 7 October that the drone is still concept-only. Mathematics can expose necessary conditions and reject inconsistent assumptions; it cannot fill the missing observations.

| Evidence branch | Decision-relevant observation | Appropriate first comparison | Amphibious connection |
|---|---|---|---|
| C001, 11 original centres | Dated identifiable canopy and edge alignment | Licensed near-date imagery for 2018; separately, shore/boat imagery or ordinary RGB aerial imagery for current cover | Contact sensing does not answer the photographic question. No amphibious requirement established. |
| C017, 32 centres | Mixed-cover composition, visibility and qualified interpretation | The same photographic alternatives, with adequate coverage of the whole cell and surroundings | A spectral or water reading is not a cover fraction or species label. |
| C027, 42 centres | Historical optical quality/cover uncertainty; separately, a justified current channel observation | Source-quality review first; current photography if warranted. For a separately justified contact task, compare shore/boat probe, USV and hovering or floating platforms | Sustained contact is a candidate use, not a consequence of the exclusion flag. Sampling positions require a fresh site assessment. |

The 85 centres are historical references, not sampling stations, routes or landing coordinates. These selected cases are not an accuracy sample. A current visit cannot directly validate the 2018 map. [Site-specific published context](KHOR_KALBA_SITE_EVIDENCE.md) confirms older drone mapping and sediment sampling at Khor Kalba, not the performance of our concept.

## What must enter the assessment

These are consequential parameter families, not a claim that every environmental interaction is modelled. Each supplied value needs units, provenance, date/conditions and an uncertainty range. Unknown is a valid result. A literature value or assumed design value is not a team measurement.

| Family | Required information | What changes the conclusion |
|---|---|---|
| Observation and dates | Intended decision, observable, historical/current date, acceptance rule, independent reference lineage | A useful current observation can still be invalid for historical accuracy. No information benefit is established without a decision and acceptance rule. |
| Access and habitat | Permissions, protected habitats, seasonal wildlife, launch/retrieval, qualified operator, lawful flight/contact constraints | A resource advantage cannot override a habitat or access constraint. Neither coordinates nor this assessment authorize deployment. |
| Mass and flight | All-up wet mass, payload/float/battery mass, air density, thrust at conditions, rotor/actuator limits, peak power, centre of mass | A heavier float kit can erase energy savings or exceed lift/battery limits. Payload must fit the same aircraft budget. |
| Water support and dynamics | Displacement/freeboard, hull geometry, centre of buoyancy, restoring stability, inertia, wind/waves/current, wet takeoff, net torque, drag, tether | Enough buoyancy does not imply upright stability, station keeping or recoverability. A tether can add forces and contaminate the measurement. |
| Sensing and optical quality | Sensor calibration/response, depth, tide, positioning/alignment, coverage/occlusion, GSD, illumination, vibration, contamination and craft-induced disturbance | A longer dwell helps only if it yields an accepted measurement; rotor wash, stirred sediment or probe drift can bias it. Conductivity is not automatically calibrated salinity. |
| Whole mission and reliability | Transit and all transitions, sampling, electronics, retries, recovery, battery derating, reserve, operator effort, failed/zero-success attempts | Compare complete costs, not motor-off dwell alone. Failures and recovery can reverse a nominal advantage. |
| Navigation and links | Actual positioning error, antenna height, line of sight, logged packet delivery, loss-of-link behaviour, onboard recording and safe recovery | Satellite target coordinates are not measured aircraft positions; a relay aircraft adds its own energy, operator and disturbance costs. |
| Ecology and economics | Baseline habitat/recruitment, hydrology/sediment, alternatives including no action, repeated controls, disturbance, cost, maintenance and lifecycle | More measurements or planted seedlings are not automatically better ecological outcomes. Carbon needs separate accounting. |

Hyperspectral, mud mobility, planting, solar, fleet coordination and communications are separate hypotheses. Add each only if it solves a defined observation or operational requirement and survives a matched simpler baseline. No covering hyperspectral experiment or implemented payload is claimed.

## Mathematics that is useful now

A [2024 Japanese pond study](https://mdpi-res.com/d_attachment/drones/drones-08-00038/article_deploy/drones-08-00038.pdf) tested amphibious sensing and relay links. Floats impaired flight; vegetation disrupted communications; an oxygen-consuming DO electrode made longer settling inappropriate in its test. Data are available by author request, not an established downloaded dataset. This supports selected component feasibility, not our design, Khor Kalba transfer or matched energy superiority.

### Buoyancy and static lift: necessary, not sufficient

For a freely floating body at rest without other vertical forces, buoyancy balances weight: `rho_water * g * V_displaced = m * g`, hence `V_required = m / rho_water`. Compare this with a documented displacement limit that preserves the intended freeboard. Geometry, leaks, loading and restoring stability still require separate assessment. This follows [Archimedes' principle](https://openstax.org/books/university-physics-volume-1/pages/14-4-archimedes-principle-and-buoyancy).

For an idealized steady airborne state with no other vertical force, `T_available * cos(tilt) >= m * g`. Equality gives no upward thrust margin. This is a necessary static screen, not proof of controllability, flight endurance or wet takeoff. Use thrust and battery capability under the actual anticipated conditions, not an unrelated catalogue maximum.

### Euler: where it genuinely belongs

In constant-mass rigid-body principal axes, the forced Euler equation is:

`I * omega_dot + omega cross (I * omega) = torque_net`.

For example, `omega_dot_x = (torque_x + (I_y - I_z) * omega_y * omega_z) / I_x`, with cyclic counterparts. Angular velocity is in rad/s, inertia in kg m² and torque in N m. The [MIT Press mechanics text, section 2.9](https://mitp-content-server.mit.edu/books/content/sectbyfn/books_pres_0/9579/sicm_edition_2.zip/chapter002.html) derives the forced equation and distinguishes angular dynamics from orientation kinematics.

This identifies the inertia and torque inputs needed for contact/transition attitude assessment. An instantaneous acceleration is **not** a stability result. A future model needs orientation, translational dynamics, controller/actuator limits, hydrodynamic forces and restoring torques, and measured validation. Moving payloads, rotor angular momentum, variable mass and added-water effects require an expanded model or justified approximation. No such calibrated model exists here. Euler's differential equations and a numerical Euler integration method are different things; selecting an integrator does not validate the physics.

### Dwell, measurement quality and resource advantage

The optional notebook includes a declared first-order response assumption: if a sensor's normalized step-error obeys `e(t) = exp(-t / tau)`, a residual error limit `epsilon` requires `t >= -tau * ln(epsilon)`. This is the team's elementary model derivation, not a specification for any selected sensor. Test applicability; settling alone excludes calibration bias, fouling and spatial drift.

For the same `n` attempted observation tasks and acceptance fraction `p > 0`, long-run expected energy per accepted observation is `E / (n*p)` and time is `T / (n*p)`. These are ratios of expectations, not the expected per-mission ratio; a mission can return zero accepted records. With equal attempted tasks, supported mode improves energy only if `p_S/p_H > E_S/E_H`, and time only if `p_S/p_H > T_S/T_H`. Acceptance must use the same predeclared quality rule, not different standards for each platform.

The [saved illustrative scenario](../examples/inspection/energy_scenario_excerpt.json) already shows approximately 170.7 versus 128.0 Wh but 750 versus 840 s. Those rounded hypothetical results imply an energy threshold near 0.749854 and a time threshold of 1.12; equal acceptance cannot improve both. A 30 s dwell or extra recovery overhead can reverse the energy advantage. These are not measured probabilities or UAE product comparisons. Unmeasured recovery costs must not silently become zero.

## Choosing the next experiment, not the most elaborate aircraft

The outside-the-box contribution is **method selection tied to an evidence gap**, rather than assigning every satellite flag to the same drone. First ask which observation could change a decision and whether an existing source can answer it. Do not infer a probability of damage from disagreement frequency. Compare alternatives using information quality, habitat safeguards, energy, time, operator effort and money separately; do not hide trade-offs in an arbitrary weighted score.

For engineering, the smallest decisive future experiment is a permitted controlled-water comparison of the same specified sensor observation: establish calibration, depth/position/settling and bias against a reference probe; then measure complete energy, elapsed time, rejected attempts, transitions and recovery against the simplest suitable method. Include a no-amphibious baseline. Tank performance would be an early engineering result, not Khor Kalba field suitability or ecological benefit. No tank test is claimed or scheduled.

For accuracy, first establish reusable independent sufficiently detailed near-date evidence, then draw the frozen held-out probability sample and perform blind interpretation. For ecology, first establish current need and suitability, with no action/protection/natural regeneration as genuine alternatives; any intervention requires the [separate outcome protocol](VALIDATION_AND_BENEFIT_TESTS.md). The three evidence tracks cannot substitute for each other.

## Reproducible companion and status

[Connected concept Colab notebook](../supplementary/Mangrove_Pulse_Connected_Concept.ipynb) embeds the unchanged saved requests, this note, exact screening code/tests and blank parameter records. It needs no dataset upload, package installation or accelerator, and exports a downloadable assessment ZIP when run in Colab. Source is [concept_screen.py](../src/concept_screen.py). Default engineering inputs are unknown; saved energy/time values remain explicitly hypothetical. It never returns deployment authorization, independent accuracy, superiority or ecological-benefit proof. Synthetic tests test equations and record handling only.

Source prepared; new Colab execution is not yet verified. The frozen EO inputs, threshold, split, predictions, scores and actual previously executed notebooks are unchanged. No new field data, local scientific run, PDF, publication or submission.
