"""Synthetic unit tests for metadata claim gates; no acquired data used."""

import unittest

from claim_checks import accepted_observation_summary, adjudication_gate


class AcceptedObservationTests(unittest.TestCase):
    def row(self, **updates):
        value = {"platform": "aircraft", "mission_energy_wh": 10.0,
                 "elapsed_min": 2.0, "attempted": 3, "accepted": 2,
                 "evidence_kind": "measured"}
        value.update(updates)
        return value

    def test_aggregates_by_platform_and_keeps_kinds_separate(self):
        result = accepted_observation_summary([
            self.row(), self.row(mission_energy_wh=5, elapsed_min=1,
                                 attempted=1, accepted=1),
            self.row(evidence_kind="hypothetical")])
        by_kind = {row["evidence_kind"]: row for row in result}
        measured, hypothetical = by_kind["measured"], by_kind["hypothetical"]
        self.assertEqual((measured["attempted"], measured["accepted"]), (4, 3))
        self.assertEqual(measured["accepted_per_wh"], 0.2)
        self.assertEqual(measured["accepted_per_min"], 1.0)
        self.assertEqual(hypothetical["accepted"], 2)
        self.assertFalse(measured["proves_superiority"])

    def test_zero_denominators_and_zero_acceptance(self):
        row = self.row(mission_energy_wh=0, elapsed_min=0, attempted=0, accepted=0)
        result = accepted_observation_summary([row])[0]
        self.assertIsNone(result["accepted_per_wh"])
        self.assertIsNone(result["accepted_per_min"])

    def test_invalid_resources_and_counts_rejected(self):
        for field, value in (("mission_energy_wh", float("nan")),
                             ("mission_energy_wh", -1), ("elapsed_min", float("inf")),
                             ("attempted", -1), ("attempted", True),
                             ("accepted", True), ("accepted", 4),
                             ("mission_energy_wh", 0), ("elapsed_min", 0)):
            with self.subTest(field=field, value=value):
                with self.assertRaises(ValueError):
                    accepted_observation_summary([self.row(**{field: value})])

    def test_evidence_kinds_are_never_combined(self):
        result = accepted_observation_summary([
            self.row(), self.row(evidence_kind="hypothetical")])
        self.assertEqual({row["evidence_kind"] for row in result},
                         {"measured", "hypothetical"})


class AdjudicationTests(unittest.TestCase):
    def row(self, **updates):
        value = {"sample_id": "s1", "inclusion_probability": 0.5,
                 "reference_label": "mangrove", "source_url": "https://example.org/ref",
                 "reference_date": "2018-11-20", "independent_reference": True,
                 "blind_interpretation": True, "prediction_class": "mangrove",
                 "target_date": "2018-11-20"}
        value.update(updates)
        return value

    def test_ready_is_not_an_accuracy_claim(self):
        result = adjudication_gate([self.row()])
        self.assertEqual(result["status"], "ready_for_review")
        self.assertTrue(result["no_accuracy_claim"])
        self.assertTrue(result["independence_is_self_declared_not_verified"])

    def test_unknown_is_counted_and_not_dropped(self):
        result = adjudication_gate([self.row(), self.row(
            sample_id="s2", reference_label="unknown")])
        self.assertEqual(result["counts"]["unknown"], 1)
        self.assertEqual(result["records"], 2)
        self.assertEqual(result["status"], "not_ready")
        self.assertFalse(result["ready_for_accuracy_claim"])

    def test_empty_and_unblinded_or_nonindependent_are_not_ready(self):
        self.assertEqual(adjudication_gate([])["status"], "not_ready")
        for changes in ({"independent_reference": False},
                        {"blind_interpretation": False}):
            with self.subTest(changes=changes):
                self.assertEqual(adjudication_gate([self.row(**changes)])["status"],
                                 "not_ready")

    def test_dates_are_iso_and_reference_mismatch_is_only_a_review_flag(self):
        invalid = adjudication_gate([self.row(target_date="2018-02-30")])
        self.assertEqual(invalid["status"], "not_ready")
        mismatch = adjudication_gate([self.row(reference_date="2017-04-10")])
        self.assertEqual(mismatch["status"], "ready_for_review")
        self.assertTrue(mismatch["review_flags"])
        self.assertFalse(mismatch["ready_for_accuracy_claim"])

    def test_missing_label_or_required_metadata_is_not_ready(self):
        result = adjudication_gate([self.row(reference_label=None, source_url="")])
        self.assertEqual(result["status"], "not_ready")
        self.assertEqual(result["counts"]["missing_or_unlabelled"], 1)

    def test_duplicate_and_invalid_probability_rejected_or_gated(self):
        with self.assertRaises(ValueError):
            adjudication_gate([self.row(), self.row()])
        for probability in (0, 1.1, float("nan"), -0.1):
            with self.subTest(probability=probability):
                result = adjudication_gate([self.row(inclusion_probability=probability)])
                self.assertEqual(result["status"], "not_ready")

    def test_wrong_date_and_prediction_are_not_ready(self):
        result = adjudication_gate([self.row(target_date="2018-11-30",
                                             prediction_class="uncertain")])
        self.assertEqual(result["status"], "not_ready")
        self.assertTrue(result["no_accuracy_claim"])


if __name__ == "__main__":
    unittest.main()
