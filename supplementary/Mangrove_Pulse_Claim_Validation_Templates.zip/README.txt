Mangrove Pulse claim-validation templates

All CSV templates are intentionally blank apart from headers. No samples, IDs, probabilities, labels, mission measurements, or ecological outcomes are fabricated. The historical reference-label target date is 2018-11-20. This date does not apply to current platform missions or ecological monitoring, which must use their actual observation dates.

For held-out map inference, sample only the 5,653 south test centres with known inclusion probabilities. Full-AOI summaries are separate and include calibration and excluded centres; excluded centres must not be labeled non-mangrove. Keep blind labels separate from the prediction join file until adjudication is complete.

The included gate code summarizes metadata only. A ready-for-review status is not accuracy validation; independence remains self-declared until verified. No field accuracy or causal ecological benefit is computed. The energy frontier in the notebook is hypothetical algebra using saved rounded illustrative inputs.

Research references:
- EAD, 2023 drone mangrove project: https://www.ead.gov.ae/en/Media-Centre/News/0-plants-one-million-mangrove
- Olofsson et al. (2014): https://doi.org/10.1016/j.rse.2014.02.015
- UAE Mangrove Restoration Guidelines: https://www.admangroves.ae/media/birkfu4i/mangrove-restoration-guidelines.pdf
