"""Metadata-only claim gates for future field-observation evidence.

These helpers summarize declared records; they do not establish measurement
quality, reference independence, ecological truth, or platform superiority.
"""

from collections import defaultdict
from datetime import date
from math import isfinite
from numbers import Real


TARGET_DATE = "2018-11-20"
LABELS = {"mangrove", "non_mangrove", "unknown"}


def _finite_nonnegative(value, name):
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite nonnegative number")
    if not isfinite(value) or value < 0:
        raise ValueError(f"{name} must be a finite nonnegative number")
    return float(value)


def _count(value, name, minimum=0):
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value


def accepted_observation_summary(records):
    """Summarize declared accepted observations per resource, separated by kind.

    Each record needs platform, mission_energy_wh, elapsed_min, attempted,
    accepted, and evidence_kind (``measured`` or ``hypothetical``). Resource
    totals must include failed attempts and recovery costs. Ratios are
    descriptive only and cannot prove superiority or equivalent quality.
    """
    groups = defaultdict(lambda: {"energy": 0.0, "minutes": 0.0,
                                 "attempted": 0, "accepted": 0})
    for index, record in enumerate(records):
        try:
            platform = record["platform"]
            kind = record["evidence_kind"]
            energy = _finite_nonnegative(record["mission_energy_wh"], "mission_energy_wh")
            minutes = _finite_nonnegative(record["elapsed_min"], "elapsed_min")
            attempted = _count(record["attempted"], "attempted")
            accepted = _count(record["accepted"], "accepted")
        except (KeyError, TypeError) as exc:
            raise ValueError(f"record {index} is missing a required field") from exc
        if not isinstance(platform, str) or not platform.strip():
            raise ValueError("platform must be a non-empty string")
        if kind not in {"measured", "hypothetical"}:
            raise ValueError("evidence_kind must be measured or hypothetical")
        if accepted > attempted:
            raise ValueError("accepted cannot exceed attempted")
        if accepted > 0 and energy == 0:
            raise ValueError("positive accepted observations require positive energy")
        if accepted > 0 and minutes == 0:
            raise ValueError("positive accepted observations require positive elapsed time")
        group = groups[(platform, kind)]
        group["energy"] += energy
        group["minutes"] += minutes
        group["attempted"] += attempted
        group["accepted"] += accepted

    result = []
    for (platform, kind), totals in sorted(groups.items()):
        accepted = totals["accepted"]
        energy, minutes = totals["energy"], totals["minutes"]
        result.append({
            "platform": platform,
            "evidence_kind": kind,
            "attempted": totals["attempted"],
            "accepted": accepted,
            "mission_energy_wh": energy,
            "elapsed_min": minutes,
            "accepted_per_wh": accepted / energy if energy else None,
            "accepted_per_min": accepted / minutes if minutes else None,
            "descriptive_only": True,
            "proves_superiority": False,
        })
    return result


def adjudication_gate(records):
    """Check whether declared reference-review metadata is ready for review.

    This deliberately does not compute field accuracy. ``independent_reference``
    is a self-declaration to be verified, never proof of independence.
    """
    rows = list(records)
    ids = set()
    counts = {label: 0 for label in LABELS}
    counts["missing_or_unlabelled"] = 0
    issues = [] if rows else ["no adjudication records supplied"]
    review_flags = []
    for index, row in enumerate(rows):
        if not isinstance(row, dict):
            issues.append(f"record {index}: record must be a mapping")
            continue
        sample_id = row.get("sample_id")
        if not isinstance(sample_id, str) or not sample_id.strip():
            issues.append(f"record {index}: missing sample_id")
        elif sample_id in ids:
            raise ValueError(f"duplicate sample_id: {sample_id}")
        else:
            ids.add(sample_id)

        label = row.get("reference_label")
        if isinstance(label, str) and label in LABELS:
            counts[label] += 1
        else:
            counts["missing_or_unlabelled"] += 1
            issues.append(f"record {index}: missing or invalid reference_label")

        probability = row.get("inclusion_probability")
        try:
            if isinstance(probability, bool) or not isinstance(probability, Real) or not isfinite(probability) or not 0 < probability <= 1:
                raise ValueError
        except (TypeError, ValueError):
            issues.append(f"record {index}: inclusion_probability must satisfy 0 < p <= 1")

        target_date = row.get("target_date")
        try:
            if not isinstance(target_date, str) or date.fromisoformat(target_date).isoformat() != target_date:
                raise ValueError
        except ValueError:
            issues.append(f"record {index}: target_date must be a valid ISO date")
        if target_date != TARGET_DATE:
            issues.append(f"record {index}: target_date must be {TARGET_DATE}")
        prediction = row.get("prediction_class")
        if not isinstance(prediction, str) or prediction not in {"mangrove", "non_mangrove"}:
            issues.append(f"record {index}: missing or invalid prediction_class")
        if not isinstance(row.get("source_url"), str) or not row["source_url"].strip():
            issues.append(f"record {index}: source_url required")
        reference_date = row.get("reference_date")
        try:
            if not isinstance(reference_date, str) or date.fromisoformat(reference_date).isoformat() != reference_date:
                raise ValueError
        except ValueError:
            issues.append(f"record {index}: reference_date must be a valid ISO date")
        else:
            if reference_date != TARGET_DATE:
                review_flags.append(f"record {index}: reference_date differs from target_date")
        if not isinstance(row.get("independent_reference"), bool):
            issues.append(f"record {index}: independent_reference boolean required")
        elif not row["independent_reference"]:
            issues.append(f"record {index}: reference independence not established")
        if not isinstance(row.get("blind_interpretation"), bool):
            issues.append(f"record {index}: blind_interpretation boolean required")
        elif not row["blind_interpretation"]:
            issues.append(f"record {index}: blind interpretation required")
    if counts["unknown"] or counts["missing_or_unlabelled"]:
        issues.append("unknown or unlabelled references prevent an accuracy claim")

    return {
        "status": "ready_for_review" if not issues else "not_ready",
        "counts": counts,
        "records": len(rows),
        "issues": issues,
        "review_flags": review_flags,
        "independence_is_self_declared_not_verified": True,
        "no_accuracy_claim": True,
        "ready_for_accuracy_claim": False,
    }
